module.exports = {
  root: true,
  extends: ["custom"],
  rules: {
    // Add backend-specific rules here
  },
}; 